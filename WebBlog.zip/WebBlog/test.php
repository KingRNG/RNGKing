<?php
//session_start();
//$_SESSION['content']=$_POST['content'];
date_default_timezone_set('prc');

$data=$_POST['content'];
$title=$_POST['title'];

$clear_data=strip_tags($data);//清洗文本中的html标签

function Get_Keywords($file_path)
{
    if(file_exists($file_path))
    {
        $str = file_get_contents($file_path);//将整个文件内容读入到一个字符串中
        $pattern = "/".str_replace("\r\n","|",$str)."/";//定义正则表达式
        $pattern = iconv('GB2312','UTF-8',$pattern);//编码转换
        return $pattern;
    }
}

function Sensitive($pattern, $string)
{
    $count = 0;//违规词的个数
    $sensitiveWord = '';//违规词
    $stringAfter = $string; //替换后的内容
    if(preg_match_all($pattern, $string, $matches))
    { //匹配到了结果
        $patternList = $matches[0];//匹配到的数组
        $count = count($patternList);
        $sensitiveWord = implode(',', $patternList); //敏感词数组转字符串
        $replaceArray = array_combine($patternList,array_fill(0,count($patternList),'*')); //把匹配到的数组进行合并，替换使用
        $stringAfter = strtr($string, $replaceArray); //结果替换
    }
    return $stringAfter;
}

function Filter($str)
{
    $pattern=Get_Keywords("D:\wamp64\www\WebBlog\keywords.txt");
    $result = Sensitive($pattern, $str);
    return $result;
}

$final_data=Filter($clear_data);
$final_title=Filter($title);

$part_data=mb_substr(strip_tags($final_data),0,4)."...";

session_start();

$servername = "localhost";
$username = "root";
$password = "123456";
$dbname = "boke";
$conn = mysqli_connect($servername, $username, $password, $dbname);

$name = $_SESSION['username'];
$avatar=$_SESSION['avatar22'];
$image=$_POST['image'];

$pattern='/src="(\/.*?(jpg|jpeg|gif|png))/';
preg_match_all($pattern,$image,$image_url);

$url=$image_url[1][0];

echo (string)$image_url[0][0];
echo PHP_EOL;
echo (string)$image_url[1][0];
echo PHP_EOL;
echo (string)$image_url[0][1];


$date=date("Y-m-d H",time());

if (!$conn)
{
    die("连接失败: ");
}
if($conn)
{
    $check_query = "INSERT INTO `文章信息表` (`用户名`, `头像`, `文章名`, `图片`, `文章内容`, `文章概要`, `点赞数`, `日期`) VALUES ('$name', '$avatar', '$final_title', '$url', '$final_data', '$part_data', '0', '$date')";
    $result = mysqli_query($conn,$check_query);
    //$check_query1="INSERT IGNORE INTO `评论信息表` (`文章名`, `用户名`, `发布时间`, `头像`, `评论内容`, `点赞数`) VALUES ('$title', '', '', '', '') ";
    //$result1 = mysqli_query($conn,$check_query1);

    //echo $avatar;
    //echo $summary;
}

$filename="D:\wamp64\www\WebBlog\admin\blog.txt";
$myfile = fopen($filename, "w");
fwrite($myfile, $clear_data);
fclose($myfile);

$handle = fopen($filename, "r");
while(!feof($handle)){
    echo fgetss($handle, 1024, '<br>');
}
fclose($handle);

header('Location:../WebBlog/index.php');
?>