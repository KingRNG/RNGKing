<!-- 主界面 -->
<!DOCTYPE HTML>
<html>
<head>
    <title>个人博客</title>
    <meta charset="utf-8"/>
    <meta name="viewport" content="width=device-width, initial-scale=1"/>
    <script src="assets/js/ie/html5shiv.js"></script>
    <link rel="stylesheet" href="assets/css/main.css"/>
    <link rel="stylesheet" href="assets/css/ie9.css"/>
    <link rel="stylesheet" href="assets/css/ie8.css"/>
    <!--图标库-->
    <link rel="stylesheet" href="assets/css/font-awesome.min.css">
    <!--Ueditor编辑器-->
    <script src="assets/ueditor/ueditor.config.js">/*引入配置文件*/</script>
    <script src="assets/ueditor/ueditor.all.js">/*引入源码文件*/</script>
</head>
<body>

<!-- Wrapper -->
<div id="wrapper">
    <!-- Header -->
    <header id="header">
        <nav class="main">
            <ul>
                <li class="search">
                    <a class="fa-search" href="#search">搜索</a>
                    <form id="search" method="get" action="#">
                        <input type="text" name="query" placeholder="博客">
                    </form>
                </li>
                <li class="menu">
                    <a class="fa-cog" href="Setting.php">设置</a>
                </li>
                <li class="menu">
                    <a class="fa-bars" href="#menu">菜单</a>
                </li>
            </ul>
        </nav>
    </header>

    <!-- Menu -->
    <section id="menu">
        <!-- Search -->
        <section>
            <form class="search" method="get" action="#">
                <input type="text" name="query" placeholder="关注"/>
            </form>
        </section>
        <!-- Links -->

        <?php

        session_start();
        $servername = "localhost";
        $username = "root";
        $password = "123456";
        $dbname = "boke";
        $conn = mysqli_connect($servername, $username, $password, $dbname);


        $name = $_SESSION['username'];

        $passname = array('filename' => $name);
        json_encode($passname);

        $check_query22 = "SELECT 个性签名,头像 FROM 用户信息表 WHERE 用户名='$name'";
        $sql_arr22 = mysqli_fetch_assoc(mysqli_query($conn,$check_query22));
        $sign22=$sql_arr22['个性签名'];
        $avatar22=$sql_arr22['头像'];

        $_SESSION['avatar22']=$avatar22;
        $_SESSION['sign22']=$sign22;

        if (!$conn)
        {
            die("连接失败: ");
        }
        if($conn)
        {

            $check_query1 = "SELECT 被关注人 FROM 关注列表 WHERE 关注人='$name'";
            $result1 = mysqli_query($conn,$check_query1);
            $datarow = mysqli_num_rows($result1);
            for($i=0;$i<$datarow;$i++)
            {
                $sql_arr = mysqli_fetch_assoc($result1);
                $focus = $sql_arr['被关注人'];
                $check_query11 = "SELECT 个性签名 FROM 用户信息表 WHERE 用户名='$focus'";
                $sql_arr11 = mysqli_fetch_assoc(mysqli_query($conn,$check_query11));
                $sign=$sql_arr11['个性签名'];

                echo "
                <section>
                <ul class=\"links\">
                    <li>
                        <a href=\"Friends.php?friend=$focus\">
                            <h3>$focus</h3>
                            <p>$sign</p>
                        </a>
                    </li>
                </ul>
                </section>";


            }
            //echo $avatar;
            //echo $summary;
        }
        ?>
    </section>

    <!-- Main -->
    <div id="main">
        <!--  Eiditor -->
        <!--  Eiditor -->
        <article>
            <form action="./test.php" method="post">
                <span style="float: left; height: 40px; width: 50px; line-height: 34px">标题:</span>
                <input type="text" name="title" style="background: white;width: 1050px;resize:none; height: 40px; float: left"/>
                <!--封面上传-->
                <span style="float: left; height: 50px; width: 50px; line-height: 34px;margin-top: 15px">封面:</span>
                <input type="button" id="j_upload_img_btn" style="width: 105px; height: 70px;border-width: 0px;border-radius: 3px;background:white;cursor:pointer;outline:none;color:black;font-size:7px;margin-left: -50px" value="封面上传"/>
                <ul id="upload_img_wrap" style="float: left; height: 40px; width: 50px; line-height: 34px"></ul>
                <!-- 加载编辑器的容器 -->
                <textarea id="imageupload" name="image" style="display: none;"></textarea>
                <!-- 使用ue -->
                <script type="text/javascript">
                    // 实例化编辑器，这里注意配置项隐藏编辑器并禁用默认的基础功能。
                    var uploadEditor = UE.getEditor("imageupload", {
                        isShow: false,
                        focus: false,
                        enableAutoSave: false,
                        autoSyncData: false,
                        autoFloatEnabled:false,
                        wordCount: false,
                        sourceEditor: null,
                        scaleEnabled:true,
                        toolbars: [["insertimage"]]
                    });
                    // 监听多图上传和上传附件组件的插入动作
                    uploadEditor.ready(function () {
                        uploadEditor.addListener("beforeInsertImage", _beforeInsertImage);
                    });
                    // 自定义按钮绑定触发多图上传和上传附件对话框事件
                    document.getElementById('j_upload_img_btn').onclick = function () {
                        var dialog = uploadEditor.getDialog("insertimage");
                        dialog.title = '多图上传';
                        dialog.render();
                        dialog.open();
                    };
                    // 多图上传动作
                    function _beforeInsertImage(t, result) {
                        var imageHtml = '';
                        for(var i in result){
                            imageHtml += '<li style="margin-left: 80px"><img src="'+result[i].src+'" alt="'+result[i].alt+'" height="70"'+' width="100"></li>';
                        }
                        document.getElementById('upload_img_wrap').innerHTML = imageHtml;
                    }
                </script>
                <!--以下引入UEditor编辑器界面-->
                <textarea type="text/plain" name="content" id="Editor"></textarea>
                <script type="text/javascript">
                    var editor = new baidu.editor.ui.Editor({toolbars:[
                            ['fontfamily', 'fontsize','indent','cleardoc']],
                        initialFrameHeight:200,
                        initialFrameWidth:1100,
                        elementPathEnabled: false,
                        enableAutoSave:false,
                        autosave:false,
                        enableContextMenu:false,
                        maximumWords:5000,
                    });
                    editor.render( 'Editor' );
                </script>
                <input type="submit" name="submit" style="width: 110px; height: 50px;border-width: 0px;border-radius: 3px;background:white;cursor:pointer;outline:none;color:black;font-size:7px;margin-left: 990px" value="发布"/>
            </form>
        </article>

        <?php
        $servername = "localhost";
        $username = "root";
        $password = "123456";
        $dbname = "boke";
        $conn = mysqli_connect($servername, $username, $password, $dbname);

        if (!$conn)
        {
            die("连接失败: ");
        }
        if($conn)
        {

            $check_query2 = "SELECT * FROM 文章信息表 WHERE 用户名='$name' ORDER BY 日期 DESC";
            $result2 = mysqli_query($conn,$check_query2);
            $datarow = mysqli_num_rows($result2);
            for($i=0;$i<$datarow;$i++)
            {
                $sql_arr = mysqli_fetch_assoc($result2);
                $article =$sql_arr['文章名'];
                $cover=$sql_arr['图片'];
                $content =$sql_arr['文章内容'];
                $summary =$sql_arr['文章概要'];
                $like =$sql_arr['点赞数'];
                $date =$sql_arr['日期'];

                $Year=date('y', strtotime($date));
                $Month=date('m', strtotime($date));
                $Day=date('d', strtotime($date));

                echo "<article class=\"post\">
                <header>
                <div class=\"title\">
                    <a href=\"Article.php?title=$article\"><h2>$article</h2></a>
                </div>
                <div class=\"meta\">
                    <time class=\"published\" datetime=\"\">$date</time>
                    <a href=\"#\" class=\"author\"><span class=\"name\">$name</span><img src=\"$avatar22\" alt=\"\"/></a>
                </div>
                </header>
                <a href=\"#\" class=\"image featured\"><img src=\"$cover\" alt=\"\"/></a>
                <p>$summary</p>
                <footer>
                <ul class=\"stats\">
                    <li><a class=\"icon fa-heart\" style=\"left: 500px\">$like</a></li>
                </ul>
                </footer>
                </article>";


            }
            //echo $avatar;
            //echo $summary;
        }
        ?>

        <!-- Pagination -->
        <ul class="actions pagination">
            <li><a href="" class="disabled button big previous">Previous Page</a></li>
            <li><a href="#" class="button big next">Next Page</a></li>
        </ul>

    </div>

    <!-- Sidebar -->
    <section id="sidebar">



        <!-- Intro -->
        <?php

        echo"       
        <section id=\"intro\">
            <a href=\"#\" class=\"logo\"><img src=\"$avatar22\" alt=\"\"/></a>
            <header>
                <h2>个性签名</h2>
                <p>$sign22</p>
            </header>
        </section>"
        ?>
        <!-- Mini Posts -->
        <section>
            <div class="mini-posts">
                <!-- Mini Post -->

                <?php

                if (!$conn)
                {
                    die("连接失败: ");
                }
                if($conn)
                {
                    $check_query3 = "SELECT * FROM 文章信息表 WHERE 用户名<>'$name' ORDER BY 点赞数 DESC ";
                    $result3 = mysqli_query($conn,$check_query3);
                    $datarow = mysqli_num_rows($result3);
                    for($i=0;$i<$datarow;$i++)
                    {
                        $sql_arr = mysqli_fetch_assoc($result3);
                        $avatar = $sql_arr['头像'];
                        $article =$sql_arr['文章名'];
                        $cover=$sql_arr['图片'];
                        $content =$sql_arr['文章内容'];
                        $summary =$sql_arr['文章概要'];
                        $like =$sql_arr['点赞数'];
                        $date =$sql_arr['日期'];

                        $Year=date('y', strtotime($date));
                        $Month=date('m', strtotime($date));
                        $Day=date('d', strtotime($date));

                        echo "
                <article class=\"mini-post\">
                                <header>
                                    <h3><a href=\"FriendArticle.php?title_friend=$article\">$summary</a></h3>
                                    <time class=\"published\" datetime=\"$date\">$date</time>
                                    <a href=\"#\" class=\"author\"><img src=\"$avatar\" alt=\"\"/></a>
                            </header>
                    <a href=\"#\" class=\"image\"><img src=\"$cover\" alt=\"\"/></a>
                </article>";


            }
            //echo $avatar;
            //echo $summary;
        }

                ?>

            </div>
        </section>

        <!-- About -->
        <section class="blurb">
            <h2>About</h2>
            <p>Mauris neque quam, fermentum ut nisl vitae, convallis maximus nisl. Sed mattis nunc id lorem euismod amet
                placerat. Vivamus porttitor magna enim, ac accumsan tortor cursus at phasellus sed ultricies.</p>
            <ul class="actions">
                <li><a href="#" class="button">Learn More</a></li>
            </ul>
        </section>
    </section>
</div>

<!-- Scripts -->
<script src="assets/js/jquery.min.js"></script>
<script src="assets/js/skel.min.js"></script>
<script src="assets/js/util.js"></script>
<!--[if lte IE 8]>
<script src="assets/js/ie/respond.min.js"></script><![endif]-->
<script src="assets/js/main.js"></script>

</body>
</html>