<!-- 登陆界面 -->
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <title>主界面</title>
    <!-- 新 Bootstrap4 核心 CSS 文件 -->
    <link rel="stylesheet" href="https://cdn.bootcss.com/bootstrap/4.1.0/css/bootstrap.min.css">

    <!-- jQuery文件。务必在bootstrap.min.js 之前引入 -->
    <script src="https://cdn.bootcss.com/jquery/3.2.1/jquery.min.js"></script>

    <!-- popper.min.js 用于弹窗、提示、下拉菜单 -->
    <script src="https://cdn.bootcss.com/popper.js/1.12.5/umd/popper.min.js"></script>

    <!-- 最新的 Bootstrap4 核心 JavaScript 文件 -->
    <script src="https://cdn.bootcss.com/bootstrap/4.1.0/js/bootstrap.min.js"></script>

    <script>
        function register() {
            //跳转到注册界面register.html进行注册
            window.open("Register.html", "_blank");  //_self,_parent,_top,_blank
        }
        function login() {
            //登录逻辑
        }
    </script>
</head>
<body>
<!-- 登录表单 -->
<form style="margin-left:50px;margin-top:80px;" action="Log.php" method="post" class="input-wrap">
    <div class="form-group">
        <label for="user" stype="display:inline;">账户：</label>
        <input type="text" class="form-control" id="user" name="username" style="display:inline;width:200px;"autocomplete="off" />
    </div>
    <div class="form-group">
        <label for="password" style="display:inline;">密码：</label>
        <input type="password" class="form-control" id="password" name="password" style="display:inline;width:200px;"autocomplete="off" />
    </div>
    <button type="submit" class="btn btn-primary" onclick="Log">登录</button>
</form>
<form style="margin-left:50px;margin-top:10px"  method="post" class="input-wrap">
<button type="submit" class="btn btn-primary" onclick="register()">注册</button>
</form>
</body>
</html>