<!-- 关注功能 -->
<?php
//session_start();
//$_SESSION['content']=$_POST['content'];
date_default_timezone_set('prc');

session_start();

$servername = "localhost";
$username = "root";
$password = "123456";
$dbname = "boke";
$conn = mysqli_connect($servername, $username, $password, $dbname);

$data=$_POST['if_focus'];
$username=$_SESSION['username'];
$name=$_SESSION['owner_name'];

$date=date("Y-m-d H-i-s",time());

if (!$conn)
{
    die("连接失败: ");
}
if($conn)
{
    if($data==1)
        $check_query = "DELETE FROM `关注列表` WHERE `关注人` = '$username' AND `被关注人` = '$name';";
    else
        $check_query = "INSERT INTO `关注列表` (`关注人`, `被关注人`) VALUES ('$username', '$name')";

    $result = mysqli_query($conn,$check_query);
    echo $data;
    //echo $summary;
}

header('Location:../WebBlog/index.php');
?>