<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <link rel="stylesheet" href="//cdn.bootcss.com/bootstrap/3.3.5/css/bootstrap.min.css">
    <!--使用bootstrap必须引入的3个文件-->
    <link rel="stylesheet" href="assets/css/font-awesome.min.css">
    <!--图标库-->
    <script src="assets/ueditor/ueditor.config.js">/*引入配置文件*/</script>
    <script src="assets/ueditor/ueditor.all.js">/*引入源码文件*/</script>
    <!--Ueditor编辑器-->
    <title>Title</title>
</head>
<body>
    <!--目前对于图片上传的问题，初步设想是让用户把图片上传的本地，在本地存储然后显示出来，但是对于文本的显示目前还不确定能
    否像图片一样实现，另外需要在本地自动创建每个用户的图片夹；博客的富文本框初步想做成类似于QQ空间发布动态一样的情况；个人
    界面的菜单框修改成关注的人的列表，上面的搜索框用于直接搜索关注的人，另外还会尝试创建关注的人的分组；最终目标是做成QQ空
    间和微博的结合网站；还有个人资料的修改按钮；-->
    <textarea id="content" rows="10" cols="50" style="border:1px solid #E5E5E5;">请输入文字</textarea>
    <script type="text/javascript">
        UE.getEditor("content");//实例化编辑器  传参,id为将要被替换的容器。
    </script>
    <!--bs3-搭配ctrl+j调用bootstrap组件-->
    <i class="fa fa-leaf"></i>
    <!--调用图标库中的图标-->
</body>
<link rel="stylesheet" href="//cdn.bootcss.com/jquery/1.11.3/jquery.min.js">
<link rel="stylesheet" href="//cdn.bootcss.com/bootstrap/3.3.5/js/bootstrap.min.js">
</html>