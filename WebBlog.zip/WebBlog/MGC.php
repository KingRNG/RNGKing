<!-- 敏感词屏蔽功能-->
<?php
function Get_Keywords($file_path)
{
    if(file_exists($file_path))
    {
        $str = file_get_contents($file_path);//将整个文件内容读入到一个字符串中
        $pattern = "/".str_replace("\r\n","|",$str)."/";//定义正则表达式
        $pattern = iconv('GB2312','UTF-8',$pattern);//编码转换
        return $pattern;
    }
}

function Sensitive($pattern, $string)
{
    $count = 0;//违规词的个数
    $sensitiveWord = '';//违规词
    $stringAfter = $string; //替换后的内容
    if(preg_match_all($pattern, $string, $matches))
    { //匹配到了结果
        $patternList = $matches[0];//匹配到的数组
        $count = count($patternList);
        $sensitiveWord = implode(',', $patternList); //敏感词数组转字符串
        $replaceArray = array_combine($patternList,array_fill(0,count($patternList),'*')); //把匹配到的数组进行合并，替换使用
        $stringAfter = strtr($string, $replaceArray); //结果替换
    }
    return $stringAfter;
}

function Filter($str)
{
    $pattern=Get_Keywords("D:\wamp64\www\WebBlog\keywords.txt");
    $result = Sensitive($pattern, $str);
    return $result;
}

$result = Filter('小白喜欢习近平');
//$result = Filter('小白');
echo $result;
?>