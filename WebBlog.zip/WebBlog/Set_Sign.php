<!-- 设置签名功能-->
<?php
session_start();
$data=$_POST['aboutme'];
$name = $_SESSION['username'];
$sex=$_POST['sex'];

$servername = "localhost";
$username = "root";
$password = "123456";
$dbname = "boke";
$conn = mysqli_connect($servername, $username, $password, $dbname);

if (!$conn)
{
    die("连接失败: ");
}
if($conn)
{

    $check_query2 = "Update 用户信息表 SET 个性签名='$data',性别='$sex' where 用户名='$name'";
    $result2 = mysqli_query($conn,$check_query2);
    header('Location:../WebBlog/Setting.php');
}

?>