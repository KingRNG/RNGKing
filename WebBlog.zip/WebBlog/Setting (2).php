<!DOCTYPE html>
<html>
<head>
    <meta charset="utf-8">
    <title>Settings</title>
    <meta http-equiv="X-UA-Compatible" content="IE=edge, chrome=1">
    <meta name="renderer" content="webkit">
    <meta property="qc:admins" content="77103107776157736375" />
    <meta property="wb:webmaster" content="c4f857219bfae3cb" />

    <link rel="stylesheet" href="./profile/base.css" type="text/css" />
    <link rel="stylesheet" href="./profile/common-less(1).css" type="text/css" />
    <link rel="stylesheet" href="./profile/moco.min.css" type="text/css" />
    <link rel="stylesheet" href="./profile/common-less.css" type="text/css" />
    <link rel="stylesheet" href="./profile/profile-less.css" type="text/css" />
    <!--Ueditor编辑器-->
    <script src="./assets/ueditor/ueditor.config.js">/*引入配置文件*/</script>
    <script src="./assets/ueditor/ueditor.all.js">/*引入源码文件*/</script>
</head>

<body >
<div id="main">
    <div class="page-settings">
        <div class="top">
            <div class="w960 mauto top_title">
                <p>个人设置</p>
            </div>
        </div>
        <div class="setting pb10">
            <div class="nav-tabs pa">
                <h class="baseinfo fl active">基本信息</h>
                <div class="cb"></div>
            </div>
            <div class="contentBox">
                <div class="formBox">
                    <!--头像上传 使用image获取-->
                    <form id="profile" action="test.php">
                        <div id="setting-profile" class="setting-wrap setting-profile">
                            <div class="wlfg-wrap clearfix ">
                                <label class="label-name" >头像：</label>
                                <div class="pr">
                                    <button type="button" id="j_upload_img_btn" class="rlf-btn-green btn-block profile-btn" style="background: #6dbfff;margin-left: 80px">封面上传</button>
                                    <br>
                                    <ul id="upload_img_wrap"></ul>
                                    <!-- 加载编辑器的容器 -->
                                    <textarea id="imageupload" name="image" style="display: none;"></textarea>
                                    <!-- 使用ue -->
                                    <script type="text/javascript">
                                        // 实例化编辑器，这里注意配置项隐藏编辑器并禁用默认的基础功能。
                                        var uploadEditor = UE.getEditor("imageupload", {
                                            isShow: false,
                                            focus: false,
                                            enableAutoSave: false,
                                            autoSyncData: false,
                                            autoFloatEnabled:false,
                                            wordCount: false,
                                            sourceEditor: null,
                                            scaleEnabled:true,
                                            toolbars: [["insertimage"]]
                                        });
                                        // 监听多图上传和上传附件组件的插入动作
                                        uploadEditor.ready(function () {
                                            uploadEditor.addListener("beforeInsertImage", _beforeInsertImage);
                                        });
                                        // 自定义按钮绑定触发多图上传和上传附件对话框事件
                                        document.getElementById('j_upload_img_btn').onclick = function () {
                                            var dialog = uploadEditor.getDialog("insertimage");
                                            dialog.title = '多图上传';
                                            dialog.render();
                                            dialog.open();
                                        };
                                        // 多图上传动作
                                        function _beforeInsertImage(t, result) {
                                            var imageHtml = '';
                                            for(var i in result){
                                                imageHtml += '<li style="margin-left: 80px"><img src="'+result[i].src+'" alt="'+result[i].alt+'" height="100"'+' width="100"></li>';
                                            }//margin用于调整位置
                                            document.getElementById('upload_img_wrap').innerHTML = imageHtml;
                                        }
                                    </script>
                                </div>
                            </div>
                            <!--昵称修改 使用nickname获取-->
                            <div class="wlfg-wrap clearfix">
                                <label class="label-name" for="nick" >昵称：</label>
                                <div class="rlf-group">
                                    <input type="text" name="nickname" id="nick"  autocomplete="off"  data-validate="require-nick"  class="moco-form-control"  placeholder="请输入昵称"/>
                                    <p class="rlf-tip-wrap errorHint color-red" ></p>
                                </div>
                            </div>
                            <div class="wlfg-wrap clearfix">
                                <label class="label-name" for="province-select">城市：</label>
                                <div class="rlf-group profile-address">
                                    <select id="province-select" class='moco-form-control'>
                                        <option value="0">选择省份</option>
                                        <option value="1">北京</option>
                                        <option value="2">天津</option>
                                        <option value="3">河北</option>
                                        <option value="4">山西</option>
                                        <option value="5">内蒙古</option>
                                        <option value="6">辽宁</option>
                                        <option value="7">吉林</option>
                                        <option value="8">黑龙江</option>
                                        <option value="9">上海</option>
                                        <option value="10">江苏</option>
                                        <option value="11">浙江</option>
                                        <option value="12">安徽</option>
                                        <option value="13">福建</option>
                                        <option value="14">江西</option>
                                        <option value="15">山东</option>
                                        <option value="16">河南</option>
                                        <option value="17">湖北</option>
                                        <option value="18">湖南</option>
                                        <option value="19">广东</option>
                                        <option value="20">海南</option>
                                        <option value="21">广西</option>
                                        <option value="22">甘肃</option>
                                        <option value="23">陕西</option>
                                        <option value="24">新疆</option>
                                        <option value="25">青海</option>
                                        <option value="26">宁夏</option>
                                        <option value="27">重庆</option>
                                        <option value="28">四川</option>
                                        <option value="29">贵州</option>
                                        <option value="30">云南</option>
                                        <option value="31">西藏</option>
                                        <option value="32">台湾</option>
                                        <option value="33">澳门</option>
                                        <option value="34">香港</option>
                                        <option value="100">其他</option>
                                    </select>
                                    <div class="cb"></div>
                                    <p class="rlf-tip-wrap errorHint color-red"></p>
                                </div>
                            </div>
                            <div class="wlfg-wrap clearfix">
                                <label class="label-name h16 lh16" >性别：</label>
                                <div class="rlf-group rlf-radio-group">
                                    <label  class="lh16"><input type="radio" value="0" checked="checked" name="sex">保密</label>
                                    <label  class="lh16"><input type="radio" value="1" name="sex">男</label>
                                    <label  class="lh16"><input type="radio" value="2" name="sex">女</label>
                                    <p class="rlf-tip-wrap errorHint color-red"></p>
                                </div>
                            </div>
                            <!--个性签名 使用aboutme获取-->
                            <div class="wlfg-wrap clearfix">
                                <label class="label-name" for="aboutme">个性签名：</label>
                                <div class="rlf-group">
                                    <div class="pr">
                                        <textarea name="aboutme"  id="aboutme"  rows="3" class="noresize js-sign moco-form-control" maxlength="50"></textarea>
                                        <p class="numCanInput js-numCanInput "></p>
                                    </div>
                                </div>
                            </div>
                            <div class="wlfg-wrap clearfix">
                                <label class="label-name"></label>
                                <div class="rlf-group">
                                    <input type="submit" name="submit" value="保存" class="rlf-btn-green btn-block profile-btn"/>
                                </div>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>

<!--script-->
<script src="./assets/settings_css/ssologin.js?v=2.0"></script>
<script type="text/javascript" src="./assets/settings_css/sea.js"></script>
<script type="text/javascript" src="./assets/settings_css/sea_config.js?v=201612141100"></script>
<script type="text/javascript">seajs.use("../"+OP_CONFIG.module+"/"+OP_CONFIG.page);</script>

</div>
</body>
</html>
