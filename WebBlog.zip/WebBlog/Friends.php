<!-- 好友主页界面 -->
<!DOCTYPE HTML>
<html>
<head>
    <title>好友界面</title>
    <meta charset="utf-8"/>
    <meta name="viewport" content="width=device-width, initial-scale=1"/>
    <script src="assets/js/ie/html5shiv.js"></script>
    <link rel="stylesheet" href="assets/css/main.css"/>
    <link rel="stylesheet" href="assets/css/ie9.css"/>
    <link rel="stylesheet" href="assets/css/ie8.css"/>
    <!--图标库-->
    <link rel="stylesheet" href="assets/css/font-awesome.min.css">
</head>
<body>

<!-- Wrapper -->
<div id="wrapper">
    <!-- Header -->
    <header id="header">
        <nav class="main">
            <ul>
                <li class="search">
                    <a class="fa-search" href="#search">搜索</a>
                    <form id="search" method="get" action="#">
                        <input type="text" name="query" placeholder="博客">
                    </form>
                </li>
                <li class="menu">
                    <a class="fa-bars" href="#menu">菜单</a>
                </li>
            </ul>
        </nav>
    </header>

    <!-- Menu -->
    <section id="menu">
        <!-- Search -->
        <section>
            <form class="search" method="get" action="#">
                <input type="text" name="query" placeholder="关注"/>
            </form>
        </section>

        <?php

        session_start();
        $servername = "localhost";
        $username = "root";
        $password = "123456";
        $dbname = "boke";
        $conn = mysqli_connect($servername, $username, $password, $dbname);


        $name = $_SESSION['username'];
        $friend = $_REQUEST['friend'];


        if (!$conn)
        {
            die("连接失败: ");
        }
        if($conn)
        {
            $check_query1 = "SELECT 被关注人 FROM 关注列表 WHERE 关注人='$name'";
            $result1 = mysqli_query($conn,$check_query1);
            $datarow = mysqli_num_rows($result1);
            for($i=0;$i<$datarow;$i++)
            {
                $sql_arr = mysqli_fetch_assoc($result1);
                $focus = $sql_arr['被关注人'];
                $check_query11 = "SELECT 个性签名 FROM 用户信息表 WHERE 用户名='$focus'";
                $sql_arr11 = mysqli_fetch_assoc(mysqli_query($conn,$check_query11));
                $sign=$sql_arr11['个性签名'];

                echo "
                <section>
                <ul class=\"links\">
                    <li>
                        <a href=\"Friends.php?friend=$focus\">
                            <h3>$focus</h3>
                            <p>$sign</p>
                        </a>
                    </li>
                </ul>
                </section>";


            }
            //echo $avatar;
            //echo $summary;
        }
        ?>
    </section>

    <!-- Main -->
    <div id="main">
        <!-- Post -->

        <?php
        if($conn)
        {
            $check_query2 = "SELECT * FROM 文章信息表 WHERE 用户名='$friend' ORDER BY 日期 DESC";
            $result2 = mysqli_query($conn,$check_query2);
            $datarow = mysqli_num_rows($result2);
            for($i=0;$i<$datarow;$i++)
            {
                $sql_arr = mysqli_fetch_assoc($result2);
                $avatar = $sql_arr['头像'];
                $article =$sql_arr['文章名'];
                $cover=$sql_arr['图片'];
                $content =$sql_arr['文章内容'];
                $summary =$sql_arr['文章概要'];
                $like =$sql_arr['点赞数'];
                $date =$sql_arr['日期'];

                $Year=date('y', strtotime($date));
                $Month=date('m', strtotime($date));
                $Day=date('d', strtotime($date));

                echo "<article class=\"post\">
                <header>
                <div class=\"title\">
                    <a href=\"FriendArticle.php?title_friend=$article\"><h2>$article</h2></a>
                </div>
                <div class=\"meta\">
                    <time class=\"published\" datetime=\"\">$date</time>
                    <a href=\"#\" class=\"author\"><span class=\"name\">$friend</span><img src=\"$avatar\" alt=\"\"/></a>
                </div>
                </header>
                <a href=\"#\" class=\"image featured\"><img src=\"$cover\" alt=\"\"/></a>
                <p>正文</p>
                <footer>
                <ul class=\"stats\">
                    <li><a class=\"icon fa-arrow-circle-right\" style=\"left: 500px\">转发</a></li>
                    <li><a class=\"icon fa-heart\" style=\"left: 500px\">$like</a></li>
                    <li><a class=\"icon fa-comment\" style=\"left: 500px\">128</a></li>
                </ul>
                </footer>
                </article>";


            }
            //echo $avatar;
            //echo $summary;
        }
        ?>

        <!-- Pagination -->
        <ul class="actions pagination">
            <li><a href="" class="disabled button big previous">Previous Page</a></li>
            <li><a href="#" class="button big next">Next Page</a></li>
        </ul>
    </div>

    <!-- Sidebar -->
    <section id="sidebar">

        <?php
        $check_query22 = "SELECT * FROM 用户信息表 WHERE 用户名='$name'";
        $sql_arr22 = mysqli_fetch_assoc(mysqli_query($conn,$check_query22));
        $sign22=$sql_arr22['个性签名'];
        $avatar22=$sql_arr22['头像'];

        echo"
        <section id=\"intro\">
            <a href=\"#\" class=\"logo\"><img src=\"$avatar22\" alt=\"\"/></a>
            <header>
                <h2>个性签名</h2>
                <p>$sign22</p>
            </header>
        </section>"
        ?>

        <!-- Mini Posts -->
        <section>
            <div class="mini-posts">
                <!-- Mini Post -->
                <?php

                if (!$conn)
                {
                    die("连接失败: ");
                }
                if($conn)
                {
                    $check_query3 = "SELECT * FROM 文章信息表 WHERE 用户名<>'$name' ORDER BY 点赞数 DESC ";
                    $result3 = mysqli_query($conn,$check_query3);
                    $datarow = mysqli_num_rows($result3);
                    for($i=0;$i<$datarow;$i++)
                    {
                        $sql_arr = mysqli_fetch_assoc($result3);
                        $avatar = $sql_arr['头像'];
                        $article =$sql_arr['文章名'];
                        $cover=$sql_arr['图片'];
                        $content =$sql_arr['文章内容'];
                        $summary =$sql_arr['文章概要'];
                        $like =$sql_arr['点赞数'];
                        $date =$sql_arr['日期'];

                        $Year=date('y', strtotime($date));
                        $Month=date('m', strtotime($date));
                        $Day=date('d', strtotime($date));

                        echo "
                <article class=\"mini-post\">
                                <header>
                                    <h3><a href=\"#\">$summary</a></h3>
                                    <time class=\"published\" datetime=\"$date\">$date</time>
                                    <a href=\"#\" class=\"author\"><img src=\"$avatar\" alt=\"\"/></a>
                            </header>
                    <a href=\"#\" class=\"image\"><img src=\"$cover\" alt=\"\"/></a>
                </article>";


                    }
                    //echo $avatar;
                    //echo $summary;
                }

                ?>

            </div>
        </section>

        <!-- About -->
        <section class="blurb">
            <h2>About</h2>
            <p>课程设计</p>
            <ul class="actions">
                <li><a href="#" class="button">Learn More</a></li>
            </ul>
        </section>
    </section>

</div>

<!-- Scripts -->
<script src="assets/js/jquery.min.js"></script>
<script src="assets/js/skel.min.js"></script>
<script src="assets/js/util.js"></script>
<!--[if lte IE 8]>
<script src="assets/js/ie/respond.min.js"></script><![endif]-->
<script src="assets/js/main.js"></script>

</body>
</html>