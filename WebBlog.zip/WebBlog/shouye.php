<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <script src="assets/js/ie/html5shiv.js"></script>
    <link rel="stylesheet" href="assets/css/main.css"/>
    <link rel="stylesheet" href="assets/css/ie9.css"/>
    <link rel="stylesheet" href="assets/css/ie8.css"/>
    <title>首页</title>
    <!-- 新 Bootstrap4 核心 CSS 文件 -->
    <link rel="stylesheet" href="https://cdn.bootcss.com/bootstrap/4.1.0/css/bootstrap.min.css">

</head>
<body>
<!-- Wrapper -->
<div id="wrapper">
    <!-- Header -->
    <header id="header">
        <!--<h1><a href="#"> 主 页 </a></h1>

        <nav class="main">
            <ul>
                <li class="search">
                    <a class="fa-search" href="#search">搜索</a>
                    <form id="search" method="get" action="#">
                        <input type="text" name="query" placeholder="博客">
                    </form>
                </li>
                <!--<li class="setting">
                    <a class="fa-sun-o" href="gerenxinxi.html">设置</a>
                </li>-->
                <li class="menu">
                    <a class="fa-bars" href="#menu">菜单</a>
                </li>
            </ul>

        </nav>
    </header>

    <!-- Menu -->
    <section id="menu">
        <!-- Search -->
        <section>
            <form class="search" method="get" action="#">
                <input type="text" name="query" placeholder="关注"/>
            </form>
        </section>
        <!-- Links -->
        <section>
            <ul class="links">
                <li>
                    <a href="#">
                        <h3>Lorem ipsum</h3>
                        <p>Feugiat tempus veroeros dolor</p>
                    </a>
                </li>
                <li>
                    <a href="#">
                        <h3>Dolor sit amet</h3>
                        <p>Sed vitae justo condimentum</p>
                    </a>
                </li>
                <li>
                    <a href="#">
                        <h3>Feugiat veroeros</h3>
                        <p>Phasellus sed ultricies mi congue</p>
                    </a>
                </li>
                <li>
                    <a href="#">
                        <h3>Etiam sed consequat</h3>
                        <p>Porta lectus amet ultricies</p>
                    </a>
                </li>
            </ul>
        </section>
        <!-- Actions -->
        <section>
            <ul class="actions vertical">
                <li><a href="#" class="button big fit">Log In</a></li>
            </ul>
        </section>
    </section>

    <!-- Main -->
    <div id="main">
        <!-- Post -->
        <?php
        $servername = "localhost";
        $username = "root";
        $password = "123456";
        $dbname = "boke";
        $conn = mysqli_connect($servername, $username, $password, $dbname);

        if (!$conn)
        {
            die("连接失败: ");
        }
        if($conn)
        {
            $check_query1 = "SELECT * FROM 文章信息表 ORDER BY 日期 DESC";
            $result1 = mysqli_query($conn,$check_query1);
            $datarow = mysqli_num_rows($result1);
            for($i=0;$i<$datarow;$i++)
            {
                $sql_arr = mysqli_fetch_assoc($result1);
                $avatar = $sql_arr['头像'];
                $article =$sql_arr['文章名'];
                $cover=$sql_arr['图片'];
                $content =$sql_arr['文章内容'];
                $summary =$sql_arr['文章概要'];
                $name = $sql_arr['用户名'];
                $like =$sql_arr['点赞数'];
                $date =$sql_arr['日期'];

                $Year=date('y', strtotime($date));
                $Month=date('m', strtotime($date));
                $Day=date('d', strtotime($date));

                echo "<article class=\"post\">
                <header>
                <div class=\"title\">
                    <a href=\"Article.php?title=$article\"><h2>$article</h2></a>
                </div>
                <div class=\"meta\">
                    <time class=\"published\" datetime=\"\">$date</time>
                    <a href=\"#\" class=\"author\"><span class=\"name\">$name</span><img src=\"images/avatar.jpg\" alt=\"\"/></a>
                </div>
                </header>
                <a href=\"#\" class=\"image featured\"><img src=\"$cover\" alt=\"\"/></a>
                <p>$summary</p>
                <footer>
                <ul class=\"stats\">
                    <li><a class=\"icon fa-heart\" style=\"left: 500px\">$like</a></li>
                </ul>
                </footer>
                </article>";


            }
            //echo $avatar;
            //echo $summary;
        }
        ?>

        <!-- Post -->
        <article class="post">
            <header>
                <div class="title">
                    <h2><a href="#">Ultricies sed magna euismod enim vitae gravida</a></h2>
                    <p>Lorem ipsum dolor amet nullam consequat etiam feugiat</p>
                </div>
                <div class="meta">
                    <time class="published" datetime="2015-10-25">October 25, 2015</time>
                    <a href="#" class="author"><span class="name">Jane Doe</span><img src="images/avatar.jpg"
                                                                                      alt=""/></a>
                </div>
            </header>
            <a href="#" class="image featured"><img src="images/pic02.jpg" alt=""/></a>
            <p>Mauris neque quam, fermentum ut nisl vitae, convallis maximus nisl. Sed mattis nunc id lorem euismod
                placerat. Vivamus porttitor magna enim, ac accumsan tortor cursus at. Phasellus sed ultricies mi non
                congue ullam corper.</p>
            <footer>
                <ul class="actions">
                    <li><a href="#" class="button big">Continue Reading</a></li>
                </ul>
                <ul class="stats">
                    <li><a href="#">General</a></li>
                    <li><a href="#" class="icon fa-heart">28</a></li>
                    <li><a href="#" class="icon fa-comment">128</a></li>
                </ul>
            </footer>

        </article>
        <!-- Post -->
        <article class="post">
            <header>
                <div class="title">
                    <h2><a href="#">Euismod et accumsan</a></h2>
                    <p>Lorem ipsum dolor amet nullam consequat etiam feugiat</p>
                </div>
                <div class="meta">
                    <time class="published" datetime="2015-10-22">October 22, 2015</time>
                    <a href="#" class="author"><span class="name">Jane Doe</span><img src="images/avatar.jpg"
                                                                                      alt=""/></a>
                </div>
            </header>
            <a href="#" class="image featured"><img src="images/pic03.jpg" alt=""/></a>
            <p>Mauris neque quam, fermentum ut nisl vitae, convallis maximus nisl. Sed mattis nunc id lorem euismod
                placerat. Vivamus porttitor magna enim, ac accumsan tortor cursus at. Phasellus sed ultricies mi non
                congue ullam corper. Praesent tincidunt sed tellus ut rutrum. Sed vitae justo condimentum, porta lectus
                vitae, ultricies congue gravida diam non fringilla. Cras vehicula tellus eu ligula viverra, ac fringilla
                turpis suscipit. Quisque vestibulum rhoncus ligula.</p>
            <footer>
                <ul class="actions">
                    <li><a href="#" class="button big">Continue Reading</a></li>
                </ul>
                <ul class="stats">
                    <li><a href="#">General</a></li>
                    <li><a href="#" class="icon fa-heart">28</a></li>
                    <li><a href="#" class="icon fa-comment">128</a></li>
                </ul>
            </footer>
        </article>

        <!-- Post -->
        <!--


        <!-- Pagination -->
        <ul class="actions pagination">
            <li><a href="" class="disabled button big previous">Previous Page</a></li>
            <li><a href="#" class="button big next">Next Page</a></li>
        </ul>

    </div>

    <!-- Sidebar -->
    <section id="sidebar">

        <!-- 登录表单 -->
        <form style="margin-left:50px;margin-top:80px;float: left" action="Log.php" method="post" class="input-wrap">
            <div class="form-group">
                <label for="user" stype="display:inline;">账户：</label>
                <input type="text" class="form-control" id="user" name="username" style="display:inline;width:200px;"autocomplete="off" />
            </div>
            <div class="form-group">
                <label for="password" style="display:inline;">密码：</label>
                <input type="password" class="form-control" id="password" name="password" style="display:inline;width:200px;"autocomplete="off" />
            </div>
            <button type="submit" class="btn btn-primary" style="background: white;height: 50px;width: 250px" onclick="log()">登录</button>
        </form>
        <form style="margin-left:50px;margin-top:10px;" action="register.html" method="post" class="input-wrap">
            <button type="submit" class="btn btn-primary" style="background: white;height: 50px;width: 250px" onclick="register()">注册</button>
        </form>

        <!-- Mini Posts -->
        <section>
            <div class="mini-posts">

                <!-- Mini Post -->
                <?php

                if (!$conn)
                {
                    die("连接失败: ");
                }
                if($conn)
                {
                    $check_query2 = "SELECT * FROM 文章信息表 ORDER BY 点赞数 DESC ";
                    $result2 = mysqli_query($conn,$check_query2);
                    $datarow = mysqli_num_rows($result2);
                    for($i=0;$i<$datarow;$i++)
                    {
                        $sql_arr = mysqli_fetch_assoc($result2);
                        $name = $sql_arr['用户名'];
                        $avatar = $sql_arr['头像'];
                        $article =$sql_arr['文章名'];
                        $cover=$sql_arr['图片'];
                        $content =$sql_arr['文章内容'];
                        $summary =$sql_arr['文章概要'];
                        $like =$sql_arr['点赞数'];
                        $date =$sql_arr['日期'];

                        $Year=date('y', strtotime($date));
                        $Month=date('m', strtotime($date));
                        $Day=date('d', strtotime($date));

                        echo "<article class=\"mini-post\">
                                <header>
                                    <h3><a href=\"#\">$summary</a></h3>
                                    <time class=\"published\" datetime=\"$date\">$date</time>
                                    <a href=\"#\" class=\"author\"><img src=\"$avatar\" alt=\"\"/></a>
                            </header>
                    <a href=\"#\" class=\"image\"><img src=\"$cover\" alt=\"\"/></a>
                </article>";


                    }
                    //echo $avatar;
                    //echo $summary;
                }

                ?>

            </div>
        </section>

        <!-- Posts List -->
        <!-- About -->
        <section class="blurb">
            <h2>About</h2>
            <p>Mauris neque quam, fermentum ut nisl vitae, convallis maximus nisl. Sed mattis nunc id lorem euismod amet
                placerat. Vivamus porttitor magna enim, ac accumsan tortor cursus at phasellus sed ultricies.</p>
            <ul class="actions">
                <li><a href="#" class="button">Learn More</a></li>
            </ul>
        </section>

        <!-- Footer -->
        <section id="footer">
            <ul class="icons">
                <li><a href="#" class="fa-twitter"><span class="label">Twitter</span></a></li>
                <li><a href="#" class="fa-facebook"><span class="label">Facebook</span></a></li>
                <li><a href="#" class="fa-instagram"><span class="label">Instagram</span></a></li>
                <li><a href="#" class="fa-rss"><span class="label">RSS</span></a></li>
                <li><a href="#" class="fa-envelope"><span class="label">Email</span></a></li>
            </ul>
        </section>

    </section>

</div>

<!-- Scripts -->
<script src="assets/js/jquery.min.js"></script>
<script src="assets/js/skel.min.js"></script>
<script src="assets/js/util.js"></script>
<!--[if lte IE 8]>
<script src="assets/js/ie/respond.min.js"></script><![endif]-->
<script src="assets/js/main.js"></script>
</body>
</html>