<!-- 设置头像功能-->
<?php
//session_start();
//$_SESSION['content']=$_POST['content'];
date_default_timezone_set('prc');

session_start();

$servername = "localhost";
$username = "root";
$password = "123456";
$dbname = "boke";
$conn = mysqli_connect($servername, $username, $password, $dbname);

$data=$_POST['aboutme'];
$name = $_SESSION['username'];
$sex=$_POST['sex'];
$image=$_POST['image'];

$pattern='/src="(\/.*?(jpg|jpeg|gif|png))/';
preg_match_all($pattern,$image,$image_url);

$url=$image_url[1][0];

echo $data;
echo PHP_EOL;
echo (string)$image_url[0][0];
echo PHP_EOL;
echo (string)$image_url[1][0];


$date=date("Y-m-d H",time());

if (!$conn)
{
    die("连接失败: ");
}
if($conn)
{
    $check_query = "UPDATE 文章信息表 SET 头像='$url' WHERE 用户名='$name'";
    $check_query1 = "UPDATE 用户信息表 SET 头像='$url' WHERE 用户名='$name'";
    $check_query2 = "Update 用户信息表 SET 个性签名='$data',性别='$sex' where 用户名='$name'";

    $result = mysqli_query($conn,$check_query);
    $result1 = mysqli_query($conn,$check_query1);
    $result2 = mysqli_query($conn,$check_query2);


    //echo $avatar;
    //echo $summary;
}

header('Location:../WebBlog/index.php');
?>