<!-- 点赞功能-->
<?php
//session_start();
//$_SESSION['content']=$_POST['content'];
date_default_timezone_set('prc');

session_start();

$servername = "localhost";
$username = "root";
$password = "123456";
$dbname = "boke";
$conn = mysqli_connect($servername, $username, $password, $dbname);

$_SESSION['avatar22']=$_SESSION['avatar22'];
$_SESSION['sign22']=$_SESSION['sign22'];
$_SESSION['username']=$_SESSION['username'];
$_SESSION['title']=$_SESSION['owner_article'];

if (!$conn)
{
    die("连接失败: ");
}
if($conn)
{

    $New_Like=$_REQUEST["New_Like"];
    $name=$_SESSION['owner_name'];
    $title=$_SESSION['owner_article'];
    $New_Like=$New_Like+1;

    $check_query = "UPDATE 文章信息表 SET 点赞数='$New_Like' WHERE 用户名='$name' AND 文章名='$title'";

    $result = mysqli_query($conn,$check_query);



    //echo $title;
}

header('Location:../WebBlog/Article_1.php');
?>
