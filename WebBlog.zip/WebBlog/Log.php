<!-- 登陆功能 -->
<?php
session_start();
$servername = "localhost";
$username = "root";
$password = "123456";
$dbname = "boke";
$conn = mysqli_connect($servername, $username, $password, $dbname);
if ($conn->connect_error)
{
    die("连接失败: " . $conn->connect_error);
}
if($conn)
{
    $name = $_POST['username'];
    $pwd = $_POST['password'];

    $check_query = "SELECT * FROM 用户信息表 WHERE 用户名='$name' AND 密码='$pwd' ";
    $result = mysqli_query($conn,$check_query);
    if ($row = mysqli_fetch_array($result))
    {//登录成功

        $_SESSION['username']=$_POST['username'];
        header('Location:../WebBlog/index.php');//跳转页面，注意路径
        exit;
    }
    else {
        exit('登录失败！点击此处 <a href="javascript:history.back(-1);">返回</a> 重试');
    }
}
?>