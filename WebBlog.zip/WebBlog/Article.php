<!-- 文章界面 -->
<!DOCTYPE HTML>
<html>
<head>
    <title>文章</title>
    <meta charset="utf-8"/>
    <meta name="viewport" content="width=device-width, initial-scale=1"/>
    <script src="assets/js/ie/html5shiv.js"></script>
    <link rel="stylesheet" href="assets/css/main.css"/>
    <link rel="stylesheet" href="assets/css/ie9.css"/>
    <link rel="stylesheet" href="assets/css/ie8.css"/>

    <!-- 新 Bootstrap4 核心 CSS 文件 -->
    <link rel="stylesheet" href="https://cdn.bootcss.com/bootstrap/4.1.0/css/bootstrap.min.css">

    <!-- jQuery文件。务必在bootstrap.min.js 之前引入 -->
    <script src="https://cdn.bootcss.com/jquery/3.2.1/jquery.min.js"></script>

    <!-- popper.min.js 用于弹窗、提示、下拉菜单 -->
    <script src="https://cdn.bootcss.com/popper.js/1.12.5/umd/popper.min.js"></script>

    <!-- 最新的 Bootstrap4 核心 JavaScript 文件 -->
    <script src="https://cdn.bootcss.com/bootstrap/4.1.0/js/bootstrap.min.js"></script>
    <!--图标库-->
    <link rel="stylesheet" href="assets/css/font-awesome.min.css">
    <!--Ueditor编辑器-->
    <script src="assets/ueditor/ueditor.config.js">/*引入配置文件*/</script>
    <script src="assets/ueditor/ueditor.all.js">/*引入源码文件*/</script>
</head>
<body>

<!-- Wrapper -->
<div id="wrapper">
    <!-- Main -->
        <!-- Post -->
    <div id="main">
        <?php

        session_start();
        $servername = "localhost";
        $username = "root";
        $password = "123456";
        $dbname = "boke";
        $conn = mysqli_connect($servername, $username, $password, $dbname);

        $title=$_REQUEST["title"];
        $avatar22=$_SESSION['avatar22'];
        $sign22=$_SESSION['sign22'];
        $ownername = $_SESSION['username'];



        $check_query = "SELECT * FROM 文章信息表 WHERE 文章名='$title'";
        $sql_arr = mysqli_fetch_assoc(mysqli_query($conn,$check_query));

        $name=$sql_arr['用户名'];
        $avatar = $sql_arr['头像'];
        $cover=$sql_arr['图片'];
        $content =$sql_arr['文章内容'];
        $like =$sql_arr['点赞数'];
        $date =$sql_arr['日期'];

        $new_like=$like;

        $_SESSION['owner_name']=$name;
        $_SESSION['owner_article']=$title;

        $check_query1 = "SELECT * FROM 评论信息表 WHERE 文章名='$title' AND 用户名='$name'";
        $result1=mysqli_query($conn,$check_query1);

        $datarow = mysqli_num_rows(mysqli_query($conn,$check_query1));


        echo "
        <center><section id=\"sidebar\" >
            <!-- Intro -->
            <section id=\"intro\">
                <a href=\"#\" class=\"logo\"><img src=\"$avatar22\" alt=\"\"/></a>

                <header>
                    <h2>个性签名</h2>
                    <p>$sign22</p>
                </header>
             
            </section>
        </center>

        <article class=\"post\">
            <header>
                <div class=\"title\">
                    <a name=\"\"><h2>$title</h2></a>
                </div>
                <div class=\"meta\">
                    <time class=\"published\" datetime=\"\">$date</time>
                    <a href=\"#\" class=\"author\"><span class=\"name\">$name</span><img src=\"$avatar\" alt=\"\"/></a>
                </div>
            </header>
            <a href=\"#\" class=\"image featured\"><img src=\"$cover\" alt=\"\"/></a>
            <p>$content</p>
            <footer>
                <ul class=\"stats\">        
                <form action=\"Set_Like.php?New_Like=$like title = \" method=\"post\">
                    <li><button style=\"left: 500px\" name=\"like\" type = \"submit\" class =\"icon fa-heart\" id =\"olike\" onclick=\"onlike()\">$like</button></li>
                </form>
                </ul>
            </footer>
        </article>";



        ?>




        <article class="post">
            <header>
                <div class="title">
                    <a href="./Article.html"><h2>评论区</h2></a>
                    <table class="table">
                                <thead>
                                </thead>
                                <tbody>
                                <?php
                                for ($i = 0; $i < $datarow; $i++) {

                                    $sql_arr1 = mysqli_fetch_assoc($result1);

                                    $article = $sql_arr1['文章名'];
                                    $name = $sql_arr1['用户名'];
                                    $date = $sql_arr1['发布时间'];
                                    $reviewer = $sql_arr1['评论人'];
                                    $avatar = $sql_arr1['头像'];
                                    $review = $sql_arr1['评论内容'];
                                    if($title==$article&&$ownername==$name) {
                                        echo "<tr><td></td> <td>$reviewer</td> <td><img src='$avatar' /></td>  <td>$review</td>  <td>$date</td> <td></td>  <br>";
                                    }
                                }
                                ?>
                                </tbody>
                            </table>
                </div>
            </header>
        </article>

        <?php
        echo "
        <form id=\"profile\" action=\"Review.php\" method=\"post\">
                <div class=\"wlfg-wrap clearfix\">

                 <label class=\"label-name\" for=\"aboutme\">发布评论：</label>
                      <div class=\"rlf-group\">
                          <div class=\"pr\">
                               <textarea name=\"review\"  id=\"aboutme\"  rows=\"3\" class=\"noresize js-sign moco-form-control\" maxlength=\"50\"></textarea>
                               <p class=\"numCanInput js-numCanInput \"></p>
                          </div>
                      </div>
                </div>
                <div class=\"wlfg-wrap clearfix\">
                     <label class=\"label-name\"></label>
                          <div class=\"rlf-group\">
                              <input type=\"submit\" name=\"submit\" value=\"发布\" class=\"rlf-btn-green btn-block profile-btn\"/>
                          </div>
                </div>
        </form>
        ";

        ?>





    </div>
</div>

<!-- Scripts -->
<script src="assets/js/jquery.min.js"></script>
<script src="assets/js/skel.min.js"></script>
<script src="assets/js/util.js"></script>
<!--[if lte IE 8]>
<script src="assets/js/ie/respond.min.js"></script><![endif]-->
<script src="assets/js/main.js"></script>

</body>
</html>