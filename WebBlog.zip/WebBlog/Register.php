<!-- 登陆功能 -->
<?php
session_start();
$servername = "localhost";
$username = "root";
$password = "123456";
$dbname = "boke";
$conn = mysqli_connect($servername, $username, $password, $dbname);
if ($conn->connect_error)
{
    die("连接失败: " . $conn->connect_error);
}
if($conn)
{
    $name = $_POST['username'];
    $pwd = $_POST['password'];
    $sex = $_POST['sex'];
    $sign = $_POST['sign'];
    $avatar="/WebBlog/images/avatar.jpg";



    $check_query = "INSERT INTO `用户信息表` (`用户名`, `密码`, `性别`, `头像`, `个性签名`) VALUES ('$name', '$pwd', '$sex', '$avatar', '$sign'); ";
    $result = mysqli_query($conn,$check_query);
    if ($result)
    {//登录成功
        header('Location:../WebBlog/shouye.php');//跳转页面，注意路径
        exit;
    }
    else {
        exit('注册失败！点击此处 <a href="javascript:history.back(-1);">返回</a> 重试');
    }
}
?>